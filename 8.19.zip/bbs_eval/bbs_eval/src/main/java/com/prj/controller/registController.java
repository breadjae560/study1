package com.prj.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prj.repository.Dao;

@WebServlet("/registController")
public class registController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String pwcheck = request.getParameter("pwcheck");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String permissionCode = request.getParameter("permissionCode");
		String query = "select id from tbl_member";

		Dao dao = new Dao();
		System.out.println(id);
		System.out.println(pw);
		System.out.println(name);
		System.out.println(email);
		System.out.println(pwcheck);
		System.out.println(permissionCode);
		
		
		switch (permissionCode) {
		case "a3345":	
			if (pw.equals(pwcheck)) {
			
				if(!id.equals(query)) {
				permissionCode = "admin";
				query = "INSERT INTO TBL_MEMBER VALUES ('" + id + "', '" + pw + "', '" + name + "', '" + email + "', '"+ permissionCode +"')";
				dao.insert(query);
				query = "commit";
				dao.insert(query);
				System.out.println("ㅡㅡ관리자 권한 회원가입(성공)ㅡㅡ");
				response.sendRedirect("mainPage.jsp");	
				}else {
					System.out.println("!ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ오류 체크(관리자 회원가입)");
				}
			}else if(id.equals(query)) { 
				out.print("<script>alert('이미 가입되어 있는 아이디입니다!')</script>");
			}else if(!pw.equals(pwcheck)) 		
				out.print("<script>alert('비밀번호 중복체크가 틀렸습니다!')</script>");
			break;
		
		case "":
			if (pw.equals(pwcheck)) {
				if(!id.equals(query)) {
				permissionCode = "user";
				query = "INSERT INTO TBL_MEMBER VALUES ('" + id + "', '" + pw + "', '" + name + "', '" + email + "', '"+ permissionCode +"')";
				dao.insert(query);
				query = "commit";
				dao.insert(query);
				System.out.println("ㅡㅡ유저 권한 회원가입(성공)ㅡㅡ");
				response.sendRedirect("mainPage.jsp");
				}else {
				}
			}else if(id.equals(query)) { 
				out.print("<script>alert('이미 가입되어 있는 아이디입니다!')</script>");			
			}else if(!pw.equals(pwcheck)) 
				out.print("<script>alert('비밀번호 중복체크가 틀렸습니다!')</script>");
			break;
		default:
			break;
		}
		
		

	}

}
