package com.prj.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.prj.domain.BoardDTO;
import com.prj.domain.MemberDTO;
import com.prj.domain.ReplyDTO;

public class Dao implements IRepository{
	Connection con = null;

	/*
	 * mariaDB String url = "jdbc:mariadb://localhost:3306/green"; String uid =
	 * "root"; String upw = "1234"; Class.forName("org.mariadb.jdbc.Driver");
	 * 
	 * OracleDB String url = "jdbc:oracle:thin:@localhost:1521/xe"; String uid =
	 * "system"; String upw = "1234"; Class.forName("oracle.jdbc.OracleDriver");
	 */

	public Connection DB_Con() {
		String url = "jdbc:oracle:thin:@localhost:1521/xe";
		String uid = "green01";
		String upw = "1234";

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(url, uid, upw);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public ArrayList<MemberDTO> select(String query) {
		con = DB_Con();
		ResultSet rs = null;
		MemberDTO iiv = new MemberDTO();
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();
		Statement stmt = null;

		try {
			stmt = con.createStatement();

			rs = stmt.executeQuery(query);

			while (rs.next()) {

				iiv.setId(rs.getString(1));
				iiv.setPw(rs.getString(2));
				list.add(iiv);
				break;

			}

			for (MemberDTO m : list) {

				System.out.println(m.getId());
				System.out.println(m.getPw());

			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {

			try {
				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return list;

	}

	public ArrayList<ReplyDTO> select_reply(String query) {
		con = DB_Con();
		ResultSet rs = null;
		ReplyDTO reply = new ReplyDTO();
		ArrayList<ReplyDTO> list = new ArrayList<ReplyDTO>();
		Statement stmt = null;

		try {
			stmt = con.createStatement();

			rs = stmt.executeQuery(query);

			while (rs.next()) {

				reply.setRno(rs.getString("rno"));
				reply.setWriter(rs.getString("writer"));
				reply.setComments(rs.getString("comments"));
				reply.setRegdate(rs.getString("regdate"));

				rs.getString(1);
				rs.getString(3);
				rs.getString(2);
				rs.getString(4);

				list.add(reply);
				break;

			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {

			try {
				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return list;

	}
	

	public void insert(String query) {

		con = DB_Con();

		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

	public void update(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void delete(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	


}
