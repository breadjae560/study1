
function dark() {
	document.querySelector('body').style.color = 'orange';
	document.querySelector('body').style.backgroundColor = 'black';
	document.querySelector('section').style.backgroundColor = 'black';
	document.querySelector('#ad1').style.color = 'white';

	try {

		document.querySelector('#client1').style.color = 'orange';
		document.querySelector('#client2').style.color = 'orange';
		document.querySelector('#client3').style.color = 'orange';
		document.querySelector('#client4').style.color = 'orange';
		document.querySelector('#client5').style.color = 'orange';
		document.querySelector('input[type=text]').style.backgroundColor = 'gray';
		document.querySelector('input[type=password]').style.backgroundColor = 'gray';

	} catch (Exception) {

	}

	document.getElementById('nightMode').setAttribute('value', '야간모드 OFF');
}

function light() {
	
	
	document.querySelector('body').style.backgroundColor = 'white';
	document.querySelector('body').style.color = 'black';
	document.querySelector('section').style.backgroundColor = 'white';

	try {
		document.querySelector('#client1').style.color = 'black';
		document.querySelector('#client2').style.color = 'black';
		document.querySelector('#client3').style.color = 'black';
		document.querySelector('#client4').style.color = 'black';
		document.querySelector('#client5').style.color = 'black';
		document.querySelector('input[type=text]').style.backgroundColor = 'white';
		document.querySelector('input[type=password]').style.backgroundColor = 'white';

	} catch (Exception) {

	}

	document.getElementById('nightMode').setAttribute('value', '야간모드 ON');

}


