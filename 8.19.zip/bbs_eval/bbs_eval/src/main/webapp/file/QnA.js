
$(function() {
		
		$("#Answer1").hide();
		$("#Answer2").hide();
		$("#Answer3").hide();
		$("#Answer4").hide();
		$("#Answer5").hide();
		$("#Answer6").hide();
		$("#Answer7").hide();
		$("#Answer8").hide();
		
	
		

		$("#Question1").on("mouseover", function() {
			$("#Answer1").slideDown();
		});
		$("#Question2").on("mouseover", function() {
			$("#Answer2").slideDown();
		});
		$("#Question3").on("mouseover", function() {
			$("#Answer3").slideDown();
		});
		$("#Question4").on("mouseover", function() {
			$("#Answer4").slideDown();
		});
		$("#Question5").on("mouseover", function() {
			$("#Answer5").slideDown();
		});
		$("#Question6").on("mouseover", function() {
			$("#Answer6").slideDown();
		});
		$("#Question7").on("mouseover", function() {
			$("#Answer7").slideDown();
		});
		$("#Question8").on("mouseover", function() {
			$("#Answer8").slideDown();
		});

		$("#Question1").on("mouseout", function() {
			$("#Answer1").slideUp();
		});
		$("#Question2").on("mouseout", function() {
			$("#Answer2").slideUp();
		});
		$("#Question3").on("mouseout", function() {
			$("#Answer3").slideUp();
		});
		$("#Question4").on("mouseout", function() {
			$("#Answer4").slideUp();
		});
		$("#Question5").on("mouseout", function() {
			$("#Answer5").slideUp();
		});
		$("#Question6").on("mouseout", function() {
			$("#Answer6").slideUp();
		});
		$("#Question7").on("mouseout", function() {
			$("#Answer7").slideUp();
		});
		$("#Question8").on("mouseout", function() {
			$("#Answer8").slideUp();
		});
		
	});