package ex02;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTable2 extends JPanel{
	
	public JTable2() {
		String[] title = {"사원번호", "부서", "직급"};
		String[][] data = {
				{"S001", "기획부", "과장"},
				{"S002", "홍보부", "대리"},
				{"S003", "개발부", "대리"}
		};
		
		JTable table = new JTable(data, title);
		JScrollPane sp = new JScrollPane(table);
		
		add(sp);
		
	}

}
