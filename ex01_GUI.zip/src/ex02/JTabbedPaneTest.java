package ex02;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class JTabbedPaneTest extends JFrame{
	super("JTable과 JTabbedPane");
	JTabbedPane tab = new JTabbedPane(JTabbedPane.TOP);
	
	JPanel one = new JPanel();
	JTable1 j1 = new JTable1();
	JPanel two = new JPanel();
	JTable2 j2 = new JTable2();
	
	one.add(j1);
	two.add(j2);
	
	tab.addTab("인사관리(기본)", one);
	tab.addTab("인사관리(세부)", two);
	
	getContentTane().add(tab, BorderLayout.CENTER);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(300, 150);
	setVisible(true);

	public static void main(String[] args) {
		new JTabbedPaneTest();
		
	}

}
