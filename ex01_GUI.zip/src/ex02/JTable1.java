package ex02;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTable1 extends JPanel{
	public JTable1() {
		String[] title = {"사원번호", "이름", "입사일"};
		String[][] data = {
				{"S001", "가", "2010-03-10"},
				{"S002", "나", "2010-03-20"},
				{"S003", "다", "2010-03-30"}
		};
		
		
		JTable table = new JTable(data, title);
		JScrollPane sp = new JScrollPane(table);
		
		add(sp);
	}

	

}
