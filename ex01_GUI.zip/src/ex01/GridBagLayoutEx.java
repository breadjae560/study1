package ex01;

import java.awt.Container;

import javax.swing.JFrame;

public class GridBagLayoutEx extends JFrame {
	public GridBagLayoutEx() {

		setTitle("GridBagLayout Test");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		
		
		c.add();
		c.add();
		c.add();
		c.add();
		c.add();
		c.add();
		c.add();
		c.add();

		setSize(300, 300);
		setVisible(true);

	}

	public static void main(String[] args) {
		new GridBagLayoutEx();

	}

}
