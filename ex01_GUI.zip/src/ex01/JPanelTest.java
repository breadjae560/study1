package ex01;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class JPanelTest extends JFrame {

	public JPanelTest() {
		setTitle("container a & container b");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setBackground(Color.gray);

		JPanel p1 = new JPanel();
		p1.setSize(150, 150);
		p1.setLocation(10, 10);
		p1.setBackground(Color.yellow);
		p1.add(new JLabel("JPane1-1 : 150 * 150"));

		add(p1);
		JPanel p2 = new JPanel();
		p2.setSize(150, 150);
		p2.setLocation(170, 10);
		p2.setBackground(Color.green);
		p2.add(new JLabel("JPane1-2 : 150 * 150"));
		add(p2);

		JButton btn = new JButton("OK");

		btn.setLocation(130, 170);
		btn.setSize(70, 30);
		add(btn);

	}

	public static void main(String[] args) {

		new JPanelTest();

	}

}
