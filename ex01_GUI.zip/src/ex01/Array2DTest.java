package ex01;

public class Array2DTest {

	public static void main(String[] args) {

		int[] array = new int[10];
		int[] array2 = { 1, 2, 3, 4, 5 };

		int[][] array2D = new int[4][5];
		
		String[][] array2D2 = {
				{"a", "b", "c", "d", "e"},
				{"a", "b", "c", "d", "e"},
				{"a", "b", "c", "d", "e"},
				{"a", "b", "c", "d", "e"}
				
		};
		
		
		
		
		
	}

}
