package ex01;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class ComboBoxEx extends JFrame{
	private String [] fruits = {"apple", "banana", "kiwi", "mango", 
			"pear", "peach", "berry", "strawberry", "blackberry"};
	private String [] names = {"11", "22", "33", "44"};
	
	public ComboBoxEx() {
		
		setTitle("텍스트 필드 만들기");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300, 150);
		setVisible(true);
		
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		
		JComboBox<String> strCombo = new JComboBox<String>(fruits);
		c.add(strCombo);
		
		JComboBox<String> nameCombo = new JComboBox<String>();
		for (int i = 0; i < names.length; i++) {
			nameCombo.addItem(names[i]);
			c.add(nameCombo);
		}
		
		
	}
 	
	
	public static void main(String[] args) {
		new ComboBoxEx();

	}

}
