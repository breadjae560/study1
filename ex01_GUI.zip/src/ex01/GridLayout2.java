package ex01;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class GridLayout2 extends JFrame {
	public GridLayout2() {

		setTitle("Ten Button Frame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		JButton b[] = new JButton[16];

		Color[] color = { Color.red, Color.orange, Color.yellow, Color.green, Color.cyan, Color.blue, Color.magenta,
				Color.gray, Color.pink, Color.LIGHT_GRAY, Color.red, Color.orange, Color.yellow, Color.green,
				Color.cyan, Color.blue };

		c.setLayout(new GridLayout(4, 16));

		for (int i = 0; i < b.length; i++) {

			b[i] = new JButton(Integer.toString(i));
			b[i].setBackground(color[i]);
			c.add(b[i]);
		}

		setSize(500, 200);
		setVisible(true);

	}

	public static void main(String[] args) {
		new GridLayout2();

	}

}
