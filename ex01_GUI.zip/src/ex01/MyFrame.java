package ex01;

import javax.swing.*;

public class MyFrame extends JFrame{
	public MyFrame() {
		setTitle("300x300 스윙 프레임");
		setSize(300,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	
	
	public static void main(String[] args) {
		MyFrame frame = new MyFrame();
	}

}
