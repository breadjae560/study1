package ex01;

import java.awt.Color;
import java.awt.Container;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Random_Layout extends JFrame {
	public Random_Layout() {

		setTitle("Random Frame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		JButton b[] = new JButton[16];

		c.setLayout(null);

		for (int i = 0; i < b.length; i++) {

			JLabel label = new JLabel(Integer.toString(i));
			label.setOpaque(true);
			label.setBackground(Color.BLUE);
			Random random = new Random();
			label.setLocation(random.nextInt(50), random.nextInt(249));
			label.setSize(10, 10);
			c.add(label);

		}

		setSize(500, 200);
		setVisible(true);

	}

	public static void main(String[] args) {
		new Random_Layout();

	}

}
