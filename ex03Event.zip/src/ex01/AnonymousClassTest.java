package ex01;

interface RemoteControl {

	void turnOn();

	void turnOff();
}

public class AnonymousClassTest {

	public static void main(String[] args) {
		RemoteControl rc = new RemoteControl() {

			@Override
			public void turnOn() {
				System.out.println("tv on");
			}

			@Override
			public void turnOff() {
				System.out.println("tv off");
			}

		};

	}

}
