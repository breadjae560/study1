package ex01;

import javax.swing.JFrame;

public class ButtonAndImageLabelFrame extends JFrame {
	public ButtonAndImageLabelFrame() {
		setTitle("이미지 레이블");
		setVisible(true);

		setSize(300, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {

	}

}
