package ex01;

class OuterClass {
	private String secret = "Time is money";

	public OuterClass() {
		InnerClass obj = new InnerClass();
		obj.print();

	}

	private class InnerClass {
		public InnerClass() {
			System.out.println("내부 클래스 생성자 입니다.");
		}

		public void print() {

		}
	}

}

public class InnerClassTest {

	public static void main(String[] args) {
		
		new OuterClass();
		
	}

}
/*
내부 클래스
 - 필드나 메소드처럼 내부 클래스도 멤버이다.
   내부 클래스는 클래스의 모든 멤버를 참조할 수 있다.
   
내부 클래스를 사용하는 이유
 - 특정 멤버 변수를 외부에서 자주 사용한다고 할때
   이를 public으로 선언하는 것은 캡슐화 개념에 어긋난다.
   이런 경우 내부 클래스를 사용하면 특정 멤버 변수를 private로 유지하면서
   자유롭게 사용할 수 있다. 특히 그래픽 이벤트처러기에서 주로 사용된다.
   
 - 하나의 장소에서만 사용되는 클래스들을 한곳에 모을 수 있다.
   만약 클래스가 하나의 장소에서만 필요하다면 클래스를 분리하기 보다 클래스의
   내부에 위치시키는 것이 가독성이 좋다.
   
 ==========================
무명 클래스(Anonymous class)
 - 클래스의 몸체는 정의되지만 이름이 없는 클래스.
   무명 클래스는 클래스를 정의하면서 동시에 객체를 생성한다.
   이름이 없기 때문에 한번만 사용이 가능하다
   무명클래스는 하나의 객체만 생성하면 되는 경우에 사용한다
   무명클래스는 그래픽 사용자 인터페이스의 이벤트 처리기를 구현하는 경우에 많이 사용된다
    
*/