package ex01;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

class MyListener implements ActionListener;

@Override
public void actionPerformed(ActionEvent e) {
	JButton btn = (JButton)e.getSource();
	btn.setText("버튼이 눌러졌습니다.");
}

class MyFrame extends JFrame{
	private JButton button;
	
	public MyFrame() {
		setTitle("이벤트 예제");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setLayout(new FlowLayout());
		
		button = new JButton("버튼을 누르시오");
		button.addActionListener(new MyListener());
		
		add(button);
		
		setSize(300, 200);
		setVisible(true);
	}
}

public class ActionEventTest {

	public void main(String[] args) {
		MyFrame f = new MyFrame();

	}

}
