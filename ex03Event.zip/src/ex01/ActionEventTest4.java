package ex01;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

class MyFrame4 extends JFrame {
	private JButton btn1;
	private JButton btn2;
	private JPanel p;
	MyListener listener = new MyListener();

	public MyFrame4() {
		setTitle("두개의 버튼에 같은 이벤트 등록");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		p = new JPanel();
		btn1 = new JButton("노란색");
		btn2 = new JButton("핑크색");

		btn1.addActionListener(listener);
		btn2.addActionListener(listener);
		
	

		p.add(btn1);
		p.add(btn2);
		add(p);

		setSize(300, 200);
		setVisible(true);
	}

	private class MyListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()== btn1) {
				p.setBackground(Color.yellow);
			}else if(e.getSource() == btn2) {
				p.setBackground(Color.pink);
			}
		}

	}
	
	
}

public class ActionEventTest4 {

	public static void main(String[] args) {
		MyFrame4 f = new MyFrame4();

	}

}

/*
이벤트 객체 정보
1) 이벤트 종류
2) 이벤트 소스
3) 화면 내 이벤트가 발생한 마우스 좌표 : getPoint(), getX(), getY()

4) 컴포넌트 내 이벤트가 발생한 마우스 좌표
5) 버튼이나 메뉴 아이템에 이벤트가 발생한 경우 버튼이나 메뉴 아이템의 문자열
6) 클릭된 마우스 버튼 번호 : getButton()
7) 마우스의 클릭 횟수 : getClickCount()
8) 키가 눌러졌다면 키의 코드 값과 문자 값
9) 체크박스, 라디오버튼에 이벤트가 발생하였다면 체크 상태

Object getSource()
현재 발생한 이벤트의 소스 컴포넌트의 레퍼런스를 리턴한다
반환 타입이 Object 이므로 캐스팅해서 사용한다.
ex) JButton b = (JButton) e.getSource();
----------------------------------------
button.addActionListener(MyActionListener);
button.addKeyListener(myKeyListener);

*/
